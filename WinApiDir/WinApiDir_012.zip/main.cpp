// WinApiDir.cpp: ���������� ����� ����� ��� ����������� ����������.
//

#include "stdafx.h"
#include "WinApiDir.h"

using namespace winapins;

int main(int argc, char * argv[])
{
	//struct lconv * lc;
	//lc = localeconv();

	//LPWSTR ws = (LPWSTR)new wchar_t;
	//wcscpy(ws, L"");
	//if (wcscmp(ws, L"") == 0) {
	//	int i = 1;
	//}
	//else {
	//	int i = 2;
	//}

	if (argc == 1) {
		fprintf(stderr, "not enough parameters!\n");
		return 1;
	}

	std::vector<std::string> vec;
	for (int i = 1; i < argc; ++i) {
		vec.push_back(static_cast<std::string>(argv[i]));
	}

	FileList wdir(vec);
	std::vector<WIN32_FIND_DATA> arFindData;
	try {
		wdir.Search();
	}
	catch (FileListException & ex) {
		setlocale(LC_ALL, "Rus");
		fprintf(stderr, "FileListException: %s", ex.what());
		setlocale(LC_ALL, "C");
	}
	
	//PrintFiles(arFindData, CP_OEMCP);
	wdir.Print(30, true);

	system("pause");

	return 0;
}

